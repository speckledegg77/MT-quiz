export const runtime = "nodejs"

import { NextResponse } from "next/server"
import { supabaseAdmin } from "../../../../lib/supabaseAdmin"
import { getQuestionById } from "../../../../lib/questionBank"
import { shuffleMcqForRoom } from "../../../../lib/mcqShuffle"

function stageFromTimes(
  phase: string,
  nowMs: number,
  openAt?: string,
  closeAt?: string,
  revealAt?: string,
  nextAt?: string
) {
  if (phase !== "running") return phase
  const open = openAt ? Date.parse(openAt) : 0
  const close = closeAt ? Date.parse(closeAt) : 0
  const reveal = revealAt ? Date.parse(revealAt) : 0
  const next = nextAt ? Date.parse(nextAt) : 0
  if (nowMs < open) return "countdown"
  if (nowMs < close) return "open"
  if (nowMs < reveal) return "wait"
  if (nowMs < next) return "reveal"
  return "needs_advance"
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const code = String(searchParams.get("code") ?? "").trim().toUpperCase()
  if (!code) return NextResponse.json({ error: "Missing code" }, { status: 400 })

  const roomRes = await supabaseAdmin.from("rooms").select("*").eq("code", code).single()
  if (roomRes.error) return NextResponse.json({ error: "Room not found" }, { status: 404 })
  const room = roomRes.data

  const playersRes = await supabaseAdmin
    .from("players")
    .select("id, name, score, joined_at")
    .eq("room_id", room.id)
    .order("joined_at", { ascending: true })

  const questionIds = Array.isArray(room.question_ids) ? room.question_ids : []
  const currentQuestionId = questionIds[room.question_index]

  const now = new Date()
  const stage = stageFromTimes(room.phase, now.getTime(), room.open_at, room.close_at, room.reveal_at, room.next_at)

  const canShowQuestion = room.phase === "running" || room.phase === "finished"
  const audioMode = String(room.audio_mode ?? "display")
  const selectedPacks = Array.isArray(room.selected_packs) ? room.selected_packs : []

  let questionPublic: any = null
  let revealData: any = null

  if (canShowQuestion && currentQuestionId) {
    const q = await getQuestionById(String(currentQuestionId))
    if (q) {
      let options = q.options
      let revealAnswerIndex = q.answerIndex

      if (q.answerType === "mcq" && q.answerIndex !== null && Array.isArray(q.options) && q.options.length > 1) {
        const shuffled = shuffleMcqForRoom(q.options, q.answerIndex, room.id, q.id)
        options = shuffled.options
        revealAnswerIndex = shuffled.answerIndex
      }

      const audioUrl = q.audioPath ? `/api/audio?path=${encodeURIComponent(q.audioPath)}` : null
      const imageUrl = q.imagePath ? `/api/image?path=${encodeURIComponent(q.imagePath)}` : null

      questionPublic = {
        id: q.id,
        roundType: q.roundType,
        answerType: q.answerType,
        text: q.text,
        options,
        audioUrl,
        imageUrl,
      }

      if (stage === "reveal" || room.phase === "finished") {
        revealData = {
          answerType: q.answerType,
          answerIndex: q.answerType === "mcq" ? revealAnswerIndex : null,
          answerText: q.answerType === "text" ? (q.answerText ?? "") : null,
          explanation: q.explanation,
        }
      }
    }
  }

  return NextResponse.json({
    serverNow: now.toISOString(),
    code: room.code,
    roomId: room.id,
    phase: room.phase,
    stage,
    audioMode,
    selectedPacks,
    questionIndex: room.question_index,
    questionCount: questionIds.length,
    times: {
      openAt: room.open_at,
      closeAt: room.close_at,
      revealAt: room.reveal_at,
      nextAt: room.next_at,
    },
    question: questionPublic,
    reveal: revealData,
    players: playersRes.data ?? [],
  })
}
